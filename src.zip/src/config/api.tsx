export const BASE_API_URL = "http://localhost:8080/";
export const FE_URL = "http://localhost:5173";